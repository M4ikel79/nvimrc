-- ============================================================================
-- FILE: lua/plugins/ui/menu.lua
-- DESCRIPTION: Fresh menu plugin configuration for nvzone/menu
-- ============================================================================

return {
  -- Volt is required for menu to work
  {
    "nvzone/volt",
    lazy = true,
  },

  -- Main menu plugin
  {
    "nvzone/menu",
    lazy = true,
    keys = {
      -- Primary menu access
      {
        "<leader><leader>",
        function()
          require("menu").open "main"
        end,
        desc = "Open main menu",
      },

      -- Quick submenu access
      {
        "<leader>mf",
        function()
          require("menu").open "files"
        end,
        desc = "Files menu",
      },
      {
        "<leader>mc",
        function()
          require("menu").open "code"
        end,
        desc = "Code menu",
      },
      {
        "<leader>mg",
        function()
          require("menu").open "git"
        end,
        desc = "Git menu",
      },
      {
        "<leader>mt",
        function()
          require("menu").open "terminal"
        end,
        desc = "Terminal menu",
      },
    },
    config = function()
      -- Context-aware right-click menu
      vim.keymap.set({ "n", "v" }, "<RightMouse>", function()
        -- Clean up any existing menus
        local old_bufs = require("menu.state").bufids
        if #old_bufs > 0 then
          vim.api.nvim_buf_call(old_bufs[1], function()
            vim.api.nvim_feedkeys("q", "x", false)
          end)
        end

        -- Execute the right click
        vim.cmd.exec '"normal! \\<RightMouse>"'

        -- Get buffer info at mouse position
        local mouse_pos = vim.fn.getmousepos()
        local buf = vim.api.nvim_win_get_buf(mouse_pos.winid)
        local ft = vim.bo[buf].ft

        -- Choose menu based on filetype
        local menu_name = "default"

        if ft == "NvimTree" then
          menu_name = "nvimtree"
        elseif ft == "markdown" then
          menu_name = "markdown"
        elseif vim.tbl_contains({ "lua", "python", "javascript", "typescript", "rust", "go", "java" }, ft) then
          menu_name = "code"
        end

        -- Open menu at mouse position
        require("menu").open(menu_name, { mouse = true })
      end, { desc = "Context menu" })
    end,
  },
}

-- ============================================================================
-- FILE: lua/menus/main.lua
-- DESCRIPTION: Main entry menu with access to all submenus
-- ============================================================================

--[[
return {
  -- Quick Actions Section
  {
    name = " Save File",
    cmd = "write",
    rtxt = "<C-s>",
  },
  {
    name = " Quit",
    cmd = function()
      local modified = vim.bo.modified
      if modified then
        local choice = vim.fn.confirm("Save changes before closing?", "&Yes\n&No\n&Cancel", 3)
        if choice == 1 then
          vim.cmd "write | quit"
        elseif choice == 2 then
          vim.cmd "quit!"
        end
      else
        vim.cmd "quit"
      end
    end,
    rtxt = "<leader>q",
  },

  { name = "separator" },

  -- Submenu Access
  {
    name = " Files & Search",
    hl = "ExBlue",
    items = "files",
  },
  {
    name = " Code Actions",
    hl = "ExGreen",
    items = "code",
  },
  {
    name = " Git Operations",
    hl = "ExRed",
    items = "git",
  },
  {
    name = " Terminal",
    hl = "ExCyan",
    items = "terminal",
  },
  {
    name = "󰖲 Window Management",
    hl = "ExYellow",
    items = "window",
  },

  { name = "separator" },

  -- Configuration
  {
    name = " Edit Config",
    cmd = function()
      vim.cmd "tabnew"
      local conf = vim.fn.stdpath "config"
      vim.cmd("tcd " .. conf .. " | e init.lua")
    end,
    rtxt = "ed",
  },
  {
    name = " Theme Selector",
    cmd = function()
      require("nvchad.themes").open()
    end,
    rtxt = "<leader>th",
  },

  { name = "separator" },

  -- Plugin Management
  {
    name = "󰒲 Lazy Plugins",
    cmd = "Lazy",
    rtxt = "<leader>L",
  },
  {
    name = "󰢛 Mason Installer",
    cmd = "Mason",
    rtxt = "<leader>M",
  },

  { name = "separator" },

  -- More Options
  {
    name = "󱂬 Session Management",
    hl = "ExPurple",
    items = "session",
  },
  {
    name = " Help & Docs",
    hl = "ExOrange",
    items = "help",
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/default.lua
-- DESCRIPTION: Default context menu (right-click fallback)
-- ============================================================================

--[[
return {
  {
    name = "󰌵 Code Action",
    cmd = vim.lsp.buf.code_action,
    rtxt = "<leader>ca",
  },
  {
    name = " Rename",
    cmd = vim.lsp.buf.rename,
    rtxt = "<leader>cr",
  },
  {
    name = " Format",
    cmd = function()
      local ok, conform = pcall(require, "conform")
      if ok then
        conform.format { async = true, lsp_fallback = true }
      else
        vim.lsp.buf.format()
      end
    end,
    rtxt = "<leader>cf",
  },

  { name = "separator" },

  {
    name = " Go to Definition",
    cmd = vim.lsp.buf.definition,
    rtxt = "gd",
  },
  {
    name = " Show References",
    cmd = "Telescope lsp_references",
    rtxt = "gr",
  },

  { name = "separator" },

  {
    name = " Copy Line",
    cmd = "normal! yy",
    rtxt = "yy",
  },
  {
    name = " Copy Content",
    cmd = "%y+",
    rtxt = "%y+",
  },

  { name = "separator" },

  {
    name = " Find Files",
    cmd = "Telescope find_files",
    rtxt = "<leader>ff",
  },
  {
    name = " Open Terminal",
    cmd = function()
      require("nvchad.term").toggle { pos = "float", id = "floatTerm" }
    end,
    rtxt = "<leader>tf",
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/code.lua
-- DESCRIPTION: LSP and code-related actions menu
-- ============================================================================

--[[
return {
  -- LSP Navigation
  {
    name = " Go to Definition",
    cmd = vim.lsp.buf.definition,
    rtxt = "gd",
  },
  {
    name = " Go to Declaration",
    cmd = vim.lsp.buf.declaration,
    rtxt = "gD",
  },
  {
    name = " Show References",
    cmd = "Telescope lsp_references",
    rtxt = "gr",
  },

  { name = "separator" },

  -- Code Actions
  {
    name = "󰌵 Code Action",
    cmd = vim.lsp.buf.code_action,
    rtxt = "<leader>ca",
  },
  {
    name = " Rename Symbol",
    cmd = vim.lsp.buf.rename,
    rtxt = "<leader>cr",
  },
  {
    name = " Format Buffer",
    cmd = function()
      local ok, conform = pcall(require, "conform")
      if ok then
        conform.format { async = true, lsp_fallback = true }
      else
        vim.lsp.buf.format()
      end
    end,
    rtxt = "<leader>cf",
  },
  {
    name = " Hover Documentation",
    cmd = vim.lsp.buf.hover,
    rtxt = "K",
  },

  { name = "separator" },

  -- Diagnostics
  {
    name = " Show Diagnostics",
    cmd = "Trouble diagnostics toggle",
    rtxt = "<leader>xx",
  },
  {
    name = " Next Diagnostic",
    cmd = vim.diagnostic.goto_next,
    rtxt = "]d",
  },
  {
    name = " Previous Diagnostic",
    cmd = vim.diagnostic.goto_prev,
    rtxt = "[d",
  },

  { name = "separator" },

  -- Debugging
  {
    name = " Debug",
    hl = "ExRed",
    items = {
      {
        name = " Continue/Start",
        cmd = function()
          require("dap").continue()
        end,
        rtxt = "<leader>dc",
      },
      {
        name = " Toggle Breakpoint",
        cmd = function()
          require("dap").toggle_breakpoint()
        end,
        rtxt = "<leader>db",
      },
      {
        name = " Step Into",
        cmd = function()
          require("dap").step_into()
        end,
        rtxt = "<leader>di",
      },
      {
        name = " Step Over",
        cmd = function()
          require("dap").step_over()
        end,
        rtxt = "<leader>do",
      },
    },
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/files.lua
-- DESCRIPTION: File operations and search menu
-- ============================================================================

--[[
return {
  -- Find Files
  {
    name = " Find Files",
    cmd = "Telescope find_files",
    rtxt = "<leader>ff",
  },
  {
    name = " Recent Files",
    cmd = "Telescope oldfiles",
    rtxt = "<leader>fr",
  },

  { name = "separator" },

  -- Search
  {
    name = " Live Grep",
    cmd = "Telescope live_grep",
    rtxt = "<leader>fw",
  },
  {
    name = " Grep String",
    cmd = "Telescope grep_string",
    rtxt = "<leader>fg",
  },

  { name = "separator" },

  -- File Explorer
  {
    name = " Toggle Explorer",
    cmd = "NvimTreeToggle",
    rtxt = "<C-n>",
  },
  {
    name = " Find in Explorer",
    cmd = "NvimTreeFindFile",
    rtxt = "<leader>E",
  },

  { name = "separator" },

  -- File Operations
  {
    name = "󰈔 Copy File Path",
    items = {
      {
        name = "Copy Absolute Path",
        cmd = function()
          local path = vim.fn.expand "%:p"
          vim.fn.setreg("+", path)
          vim.notify("Copied: " .. path, vim.log.levels.INFO)
        end,
      },
      {
        name = "Copy Relative Path",
        cmd = function()
          local path = vim.fn.expand "%:."
          vim.fn.setreg("+", path)
          vim.notify("Copied: " .. path, vim.log.levels.INFO)
        end,
      },
      {
        name = "Copy File Name",
        cmd = function()
          local path = vim.fn.expand "%:t"
          vim.fn.setreg("+", path)
          vim.notify("Copied: " .. path, vim.log.levels.INFO)
        end,
      },
    },
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/git.lua
-- DESCRIPTION: Git operations menu
-- ============================================================================

--[[
return {
  -- LazyGit
  {
    name = " LazyGit",
    cmd = "LazyGit",
    rtxt = "<leader>gg",
  },
  {
    name = " Git Log",
    cmd = "LazyGitLog",
    rtxt = "<leader>gl",
  },

  { name = "separator" },

  -- Hunk Operations
  {
    name = " Stage Hunk",
    cmd = function()
      require("gitsigns").stage_hunk()
    end,
    rtxt = "<leader>gs",
  },
  {
    name = " Reset Hunk",
    cmd = function()
      require("gitsigns").reset_hunk()
    end,
    rtxt = "<leader>gr",
  },
  {
    name = " Preview Hunk",
    cmd = function()
      require("gitsigns").preview_hunk()
    end,
    rtxt = "<leader>gp",
  },

  { name = "separator" },

  -- Blame & Diff
  {
    name = " Blame Line",
    cmd = function()
      require("gitsigns").blame_line { full = true }
    end,
    rtxt = "<leader>gb",
  },
  {
    name = " Diff This",
    cmd = function()
      require("gitsigns").diffthis()
    end,
    rtxt = "<leader>gd",
  },

  { name = "separator" },

  -- Telescope Git
  {
    name = " Git Status",
    cmd = "Telescope git_status",
    rtxt = "<leader>gt",
  },
  {
    name = " Git Commits",
    cmd = "Telescope git_commits",
    rtxt = "<leader>gm",
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/terminal.lua
-- DESCRIPTION: Terminal operations menu
-- ============================================================================

--[[
return {
  -- Open Terminals
  {
    name = " Floating Terminal",
    cmd = function()
      require("nvchad.term").toggle { pos = "float", id = "floatTerm" }
    end,
    rtxt = "<leader>tf",
  },
  {
    name = " Horizontal Terminal",
    cmd = function()
      require("nvchad.term").toggle { pos = "sp", id = "htoggleTerm" }
    end,
    rtxt = "<leader>th",
  },
  {
    name = " Vertical Terminal",
    cmd = function()
      require("nvchad.term").toggle { pos = "vsp", id = "vtoggleTerm" }
    end,
    rtxt = "<leader>tv",
  },

  { name = "separator" },

  -- Run Commands
  {
    name = " Run Current File",
    cmd = function()
      local runners = {
        python = "python3 %",
        javascript = "node %",
        typescript = "ts-node %",
        rust = "cargo run",
        go = "go run %",
        lua = "lua %",
      }
      local ft = vim.bo.filetype
      local cmd = runners[ft]
      if cmd then
        cmd = cmd:gsub("%%", vim.fn.expand "%:p")
        require("nvchad.term").send(cmd, "horizontal")
        vim.notify("Running: " .. cmd, vim.log.levels.INFO)
      else
        vim.notify("No runner for: " .. ft, vim.log.levels.WARN)
      end
    end,
    rtxt = "<leader>tr",
  },

  { name = "separator" },

  -- Quick Tools
  {
    name = " LazyGit",
    cmd = function()
      require("nvchad.term").send("lazygit", "float")
    end,
    rtxt = "<leader>tg",
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/window.lua
-- DESCRIPTION: Window and buffer management menu
-- ============================================================================

--[[
return {
  -- Split Windows
  {
    name = " Split Below",
    cmd = "split",
    rtxt = "<leader>-",
  },
  {
    name = " Split Right",
    cmd = "vsplit",
    rtxt = "<leader>|",
  },
  {
    name = " Close Window",
    cmd = "close",
    rtxt = "<leader>wd",
  },

  { name = "separator" },

  -- Buffer Navigation
  {
    name = " Previous Buffer",
    cmd = "bprevious",
    rtxt = "<A-,>",
  },
  {
    name = " Next Buffer",
    cmd = "bnext",
    rtxt = "<A-.>",
  },
  {
    name = " Close Buffer",
    cmd = "Bdelete",
    rtxt = "<A-c>",
  },
  {
    name = " Buffer Picker",
    cmd = "Telescope buffers",
    rtxt = "<C-p>",
  },

  { name = "separator" },

  -- Tabs
  {
    name = " New Tab",
    cmd = "tabnew",
    rtxt = "<leader>tn",
  },
  {
    name = " Close Tab",
    cmd = "tabclose",
    rtxt = "<leader>tc",
  },
  {
    name = " Next Tab",
    cmd = "tabnext",
    rtxt = "<leader>tl",
  },
  {
    name = " Previous Tab",
    cmd = "tabprevious",
    rtxt = "<leader>th",
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/session.lua
-- DESCRIPTION: Session management menu
-- ============================================================================

--[[
return {
  {
    name = " Save Session",
    cmd = function()
      local name = vim.fn.input("Session name: ", "", "file")
      if name ~= "" then
        local session_dir = vim.fn.stdpath "data" .. "/sessions"
        vim.fn.mkdir(session_dir, "p")
        local session_file = session_dir .. "/" .. name .. ".vim"
        vim.cmd("mksession! " .. session_file)
        vim.notify("Session saved: " .. name, vim.log.levels.INFO)
      end
    end,
  },
  {
    name = " Load Session",
    cmd = function()
      local session_dir = vim.fn.stdpath "data" .. "/sessions"
      local sessions = vim.fn.glob(session_dir .. "/*.vim", false, true)
      if #sessions == 0 then
        vim.notify("No sessions found", vim.log.levels.WARN)
        return
      end
      local session_names = {}
      for _, session in ipairs(sessions) do
        table.insert(session_names, vim.fn.fnamemodify(session, ":t:r"))
      end
      vim.ui.select(session_names, { prompt = "Select session:" }, function(choice)
        if choice then
          local session_file = session_dir .. "/" .. choice .. ".vim"
          vim.cmd("source " .. session_file)
          vim.notify("Session loaded: " .. choice, vim.log.levels.INFO)
        end
      end)
    end,
  },

  { name = "separator" },

  {
    name = " Change to Project Root",
    cmd = function()
      local git_root = vim.fn.systemlist("git rev-parse --show-toplevel")[1]
      if vim.v.shell_error == 0 then
        vim.cmd("cd " .. git_root)
        vim.notify("Changed to: " .. git_root, vim.log.levels.INFO)
      else
        vim.notify("No git root found", vim.log.levels.WARN)
      end
    end,
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/help.lua
-- DESCRIPTION: Help and documentation menu
-- ============================================================================

--[[
return {
  {
    name = " Help Tags",
    cmd = "Telescope help_tags",
    rtxt = "<leader>fh",
  },
  {
    name = " Show Keymaps",
    cmd = "Telescope keymaps",
    rtxt = "<leader>fk",
  },
  {
    name = " All Commands",
    cmd = "Telescope commands",
    rtxt = "<leader>fc",
  },

  { name = "separator" },

  {
    name = " LSP Info",
    cmd = "LspInfo",
    rtxt = "<leader>li",
  },
  {
    name = " Mason Info",
    cmd = "Mason",
    rtxt = "<leader>M",
  },
  {
    name = " Lazy Info",
    cmd = "Lazy",
    rtxt = "<leader>L",
  },

  { name = "separator" },

  {
    name = " Notification History",
    cmd = "Telescope notify",
    rtxt = "<leader>nh",
  },
  {
    name = " Dismiss Notifications",
    cmd = function()
      require("notify").dismiss { silent = true, pending = true }
    end,
    rtxt = "<leader>un",
  },
}
]]
--

-- ============================================================================
-- FILE: lua/menus/markdown.lua
-- DESCRIPTION: Markdown and Obsidian menu
-- ============================================================================

--[[
return {
  -- Obsidian Notes
  {
    name = " New Note",
    cmd = "ObsidianNew",
    rtxt = "<leader>on",
  },
  {
    name = " Quick Switch",
    cmd = "ObsidianQuickSwitch",
    rtxt = "<leader>oq",
  },
  {
    name = " Search Notes",
    cmd = "ObsidianSearch",
    rtxt = "<leader>os",
  },

  { name = "separator" },

  -- Daily Notes
  {
    name = " Today's Note",
    cmd = "ObsidianToday",
    rtxt = "<leader>ot",
  },

  { name = "separator" },

  -- Markdown Preview
  {
    name = " Preview",
    cmd = "MarkdownPreview",
    rtxt = "<leader>mp",
  },
  {
    name = " Stop Preview",
    cmd = "MarkdownPreviewStop",
    rtxt = "<leader>ms",
  },

  { name = "separator" },

  -- Standard Actions
  {
    name = " Format",
    cmd = function()
      local ok, conform = pcall(require, "conform")
      if ok then
        conform.format { async = true, lsp_fallback = true }
      else
        vim.lsp.buf.format()
      end
    end,
    rtxt = "<leader>cf",
  },
}
]]
--

-- ============================================================================
-- IMPORTANT NOTES:
-- ============================================================================
-- 1. This single file contains EVERYTHING you need
-- 2. The menu files are shown as comments - uncomment and create them as separate files
-- 3. The plugin looks for menus in lua/menus/ directory
-- 4. Menu file names must match the string you pass to require("menu").open()
--    Example: require("menu").open("main") looks for lua/menus/main.lua
-- 5. Each menu must return a table with the structure shown above
-- 6. Use "items" key with a string to reference another menu file
-- 7. Use "items" key with a table for inline nested menus
-- ============================================================================
